#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private IFVGProPlus[] cacheIFVGProPlus;

		
		public IFVGProPlus IFVGProPlus(bool filterByHtfFvg, bool filterByLiquiditySweep, IFVGProDetectionMode detectionMode, IFVGProBiasMode biasMode, bool allowExtendedIfvgs, bool requireBeIntact, int setupHistory, double minimumIfvgSizePoints, bool showIfvgLineLabel, int ifvgFillOpacity, string ifvgLabelText, int ifvgLabelFontSize, int liquidityLeftStrength, int liquidityRightStrength, int maxHiddenHtfFvgs, bool alertPotentialIfvg, bool alertBullishIfvgConfirmed, bool alertBearishIfvgConfirmed)
		{
			return IFVGProPlus(Input, filterByHtfFvg, filterByLiquiditySweep, detectionMode, biasMode, allowExtendedIfvgs, requireBeIntact, setupHistory, minimumIfvgSizePoints, showIfvgLineLabel, ifvgFillOpacity, ifvgLabelText, ifvgLabelFontSize, liquidityLeftStrength, liquidityRightStrength, maxHiddenHtfFvgs, alertPotentialIfvg, alertBullishIfvgConfirmed, alertBearishIfvgConfirmed);
		}


		
		public IFVGProPlus IFVGProPlus(ISeries<double> input, bool filterByHtfFvg, bool filterByLiquiditySweep, IFVGProDetectionMode detectionMode, IFVGProBiasMode biasMode, bool allowExtendedIfvgs, bool requireBeIntact, int setupHistory, double minimumIfvgSizePoints, bool showIfvgLineLabel, int ifvgFillOpacity, string ifvgLabelText, int ifvgLabelFontSize, int liquidityLeftStrength, int liquidityRightStrength, int maxHiddenHtfFvgs, bool alertPotentialIfvg, bool alertBullishIfvgConfirmed, bool alertBearishIfvgConfirmed)
		{
			if (cacheIFVGProPlus != null)
				for (int idx = 0; idx < cacheIFVGProPlus.Length; idx++)
					if (cacheIFVGProPlus[idx].FilterByHtfFvg == filterByHtfFvg && cacheIFVGProPlus[idx].FilterByLiquiditySweep == filterByLiquiditySweep && cacheIFVGProPlus[idx].DetectionMode == detectionMode && cacheIFVGProPlus[idx].BiasMode == biasMode && cacheIFVGProPlus[idx].AllowExtendedIfvgs == allowExtendedIfvgs && cacheIFVGProPlus[idx].RequireBeIntact == requireBeIntact && cacheIFVGProPlus[idx].SetupHistory == setupHistory && cacheIFVGProPlus[idx].MinimumIfvgSizePoints == minimumIfvgSizePoints && cacheIFVGProPlus[idx].ShowIfvgLineLabel == showIfvgLineLabel && cacheIFVGProPlus[idx].IfvgFillOpacity == ifvgFillOpacity && cacheIFVGProPlus[idx].IfvgLabelText == ifvgLabelText && cacheIFVGProPlus[idx].IfvgLabelFontSize == ifvgLabelFontSize && cacheIFVGProPlus[idx].LiquidityLeftStrength == liquidityLeftStrength && cacheIFVGProPlus[idx].LiquidityRightStrength == liquidityRightStrength && cacheIFVGProPlus[idx].MaxHiddenHtfFvgs == maxHiddenHtfFvgs && cacheIFVGProPlus[idx].AlertPotentialIfvg == alertPotentialIfvg && cacheIFVGProPlus[idx].AlertBullishIfvgConfirmed == alertBullishIfvgConfirmed && cacheIFVGProPlus[idx].AlertBearishIfvgConfirmed == alertBearishIfvgConfirmed && cacheIFVGProPlus[idx].EqualsInput(input))
						return cacheIFVGProPlus[idx];
			return CacheIndicator<IFVGProPlus>(new IFVGProPlus(){ FilterByHtfFvg = filterByHtfFvg, FilterByLiquiditySweep = filterByLiquiditySweep, DetectionMode = detectionMode, BiasMode = biasMode, AllowExtendedIfvgs = allowExtendedIfvgs, RequireBeIntact = requireBeIntact, SetupHistory = setupHistory, MinimumIfvgSizePoints = minimumIfvgSizePoints, ShowIfvgLineLabel = showIfvgLineLabel, IfvgFillOpacity = ifvgFillOpacity, IfvgLabelText = ifvgLabelText, IfvgLabelFontSize = ifvgLabelFontSize, LiquidityLeftStrength = liquidityLeftStrength, LiquidityRightStrength = liquidityRightStrength, MaxHiddenHtfFvgs = maxHiddenHtfFvgs, AlertPotentialIfvg = alertPotentialIfvg, AlertBullishIfvgConfirmed = alertBullishIfvgConfirmed, AlertBearishIfvgConfirmed = alertBearishIfvgConfirmed }, input, ref cacheIFVGProPlus);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.IFVGProPlus IFVGProPlus(bool filterByHtfFvg, bool filterByLiquiditySweep, IFVGProDetectionMode detectionMode, IFVGProBiasMode biasMode, bool allowExtendedIfvgs, bool requireBeIntact, int setupHistory, double minimumIfvgSizePoints, bool showIfvgLineLabel, int ifvgFillOpacity, string ifvgLabelText, int ifvgLabelFontSize, int liquidityLeftStrength, int liquidityRightStrength, int maxHiddenHtfFvgs, bool alertPotentialIfvg, bool alertBullishIfvgConfirmed, bool alertBearishIfvgConfirmed)
		{
			return indicator.IFVGProPlus(Input, filterByHtfFvg, filterByLiquiditySweep, detectionMode, biasMode, allowExtendedIfvgs, requireBeIntact, setupHistory, minimumIfvgSizePoints, showIfvgLineLabel, ifvgFillOpacity, ifvgLabelText, ifvgLabelFontSize, liquidityLeftStrength, liquidityRightStrength, maxHiddenHtfFvgs, alertPotentialIfvg, alertBullishIfvgConfirmed, alertBearishIfvgConfirmed);
		}


		
		public Indicators.IFVGProPlus IFVGProPlus(ISeries<double> input , bool filterByHtfFvg, bool filterByLiquiditySweep, IFVGProDetectionMode detectionMode, IFVGProBiasMode biasMode, bool allowExtendedIfvgs, bool requireBeIntact, int setupHistory, double minimumIfvgSizePoints, bool showIfvgLineLabel, int ifvgFillOpacity, string ifvgLabelText, int ifvgLabelFontSize, int liquidityLeftStrength, int liquidityRightStrength, int maxHiddenHtfFvgs, bool alertPotentialIfvg, bool alertBullishIfvgConfirmed, bool alertBearishIfvgConfirmed)
		{
			return indicator.IFVGProPlus(input, filterByHtfFvg, filterByLiquiditySweep, detectionMode, biasMode, allowExtendedIfvgs, requireBeIntact, setupHistory, minimumIfvgSizePoints, showIfvgLineLabel, ifvgFillOpacity, ifvgLabelText, ifvgLabelFontSize, liquidityLeftStrength, liquidityRightStrength, maxHiddenHtfFvgs, alertPotentialIfvg, alertBullishIfvgConfirmed, alertBearishIfvgConfirmed);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.IFVGProPlus IFVGProPlus(bool filterByHtfFvg, bool filterByLiquiditySweep, IFVGProDetectionMode detectionMode, IFVGProBiasMode biasMode, bool allowExtendedIfvgs, bool requireBeIntact, int setupHistory, double minimumIfvgSizePoints, bool showIfvgLineLabel, int ifvgFillOpacity, string ifvgLabelText, int ifvgLabelFontSize, int liquidityLeftStrength, int liquidityRightStrength, int maxHiddenHtfFvgs, bool alertPotentialIfvg, bool alertBullishIfvgConfirmed, bool alertBearishIfvgConfirmed)
		{
			return indicator.IFVGProPlus(Input, filterByHtfFvg, filterByLiquiditySweep, detectionMode, biasMode, allowExtendedIfvgs, requireBeIntact, setupHistory, minimumIfvgSizePoints, showIfvgLineLabel, ifvgFillOpacity, ifvgLabelText, ifvgLabelFontSize, liquidityLeftStrength, liquidityRightStrength, maxHiddenHtfFvgs, alertPotentialIfvg, alertBullishIfvgConfirmed, alertBearishIfvgConfirmed);
		}


		
		public Indicators.IFVGProPlus IFVGProPlus(ISeries<double> input , bool filterByHtfFvg, bool filterByLiquiditySweep, IFVGProDetectionMode detectionMode, IFVGProBiasMode biasMode, bool allowExtendedIfvgs, bool requireBeIntact, int setupHistory, double minimumIfvgSizePoints, bool showIfvgLineLabel, int ifvgFillOpacity, string ifvgLabelText, int ifvgLabelFontSize, int liquidityLeftStrength, int liquidityRightStrength, int maxHiddenHtfFvgs, bool alertPotentialIfvg, bool alertBullishIfvgConfirmed, bool alertBearishIfvgConfirmed)
		{
			return indicator.IFVGProPlus(input, filterByHtfFvg, filterByLiquiditySweep, detectionMode, biasMode, allowExtendedIfvgs, requireBeIntact, setupHistory, minimumIfvgSizePoints, showIfvgLineLabel, ifvgFillOpacity, ifvgLabelText, ifvgLabelFontSize, liquidityLeftStrength, liquidityRightStrength, maxHiddenHtfFvgs, alertPotentialIfvg, alertBullishIfvgConfirmed, alertBearishIfvgConfirmed);
		}

	}
}

#endregion
